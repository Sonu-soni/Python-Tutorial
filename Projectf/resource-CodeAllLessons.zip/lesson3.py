
num_1 = input("Enter the first number")
num_2 = input("Enter the second number")

print "The First number multiplied by the second number is:"
print num_1*num_2
