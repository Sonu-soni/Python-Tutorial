import sumvalues as sv

num_vals = [5,10,15,20]
print sv.sumvalues(num_vals)
