
for x in range(0,10):
    print "This line has been printed",
    print x,
    print "times"

