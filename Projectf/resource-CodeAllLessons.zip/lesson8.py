def formula(a,b):
    result = (a+b)/b
    return result

print formula(4,4)
formula(2,0)

