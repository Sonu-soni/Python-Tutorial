x = 21
def function():
    x = x+1
    print x

function()
