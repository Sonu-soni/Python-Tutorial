minutes = 60
#minutes per hour
hours = 24
#hours per day
days = 7
#days per week

#print minutes per day
print minutes*hours
print "Minutes Per Day"

print hours*days
print "Hours per week"
