def sumvalues(A):
    result = 0
    for x in A:
        result = result+x
    return result


