import urllib as url
web_content = url.urlretrieve("https://docs.python.org/2/library/urllib.html","urllib.html")
